package com.fzu.userBean;

public class CourseBean {
	private String courseNo;
	private String courseName;
	private String courseTime;
	private String coursePlace;
	private String courseMaterial;
	private String teacherName;
	public String getCourseNo() {
		return courseNo;
	}
	public void setCourseNo(String courseNo) {
		this.courseNo = courseNo;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getCourseTime() {
		return courseTime;
	}
	public void setCourseTime(String courseTime) {
		this.courseTime = courseTime;
	}
	public String getCoursePlace() {
		return coursePlace;
	}
	public void setCoursePlace(String coursePlace) {
		this.coursePlace = coursePlace;
	}
	public String getCourseMaterial() {
		return courseMaterial;
	}
	public void setCourseMaterial(String courseMaterial) {
		this.courseMaterial = courseMaterial;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

}
