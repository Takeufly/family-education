package com.fzu.userBean;

public class MyCourseBean {
	private String Cno;
	private String Cname;
	private String Ctime;
	private String Cplace;
	private String Cmeterial;
	private String Sname;
	public String getCno() {
		return Cno;
	}
	public void setCno(String cno) {
		Cno = cno;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getCtime() {
		return Ctime;
	}
	public void setCtime(String ctime) {
		Ctime = ctime;
	}
	public String getCplace() {
		return Cplace;
	}
	public void setCplace(String cplace) {
		Cplace = cplace;
	}
	public String getCmeterial() {
		return Cmeterial;
	}
	public void setCmeterial(String cmeterial) {
		Cmeterial = cmeterial;
	}
	public String getSname() {
		return Sname;
	}
	public void setSname(String sname) {
		Sname = sname;
	}
	
}
