package com.fzu.userBean;

public class Student {

	private String Sno;
	private String Sname;
	private String Ssex;
	private String Sage;
	private String Sgrade;
	private String Simages;

	public String getSno() {
		return Sno;
	}
	public void setSno(String sno) {
		Sno = sno;
	}
	public String getSname() {
		return Sname;
	}
	public void setSname(String sname) {
		Sname = sname;
	}
	public String getSsex() {
		return Ssex;
	}
	public void setSsex(String ssex) {
		Ssex = ssex;
	}
	public String getSage() {
		return Sage;
	}
	public void setSage(String sage) {
		Sage = sage;
	}
	public String getSgrade() {
		return Sgrade;
	}
	public void setSgrade(String sgrade) {
		Sgrade = sgrade;
	}
	public String getSimages() {
		return Simages;
	}
	public void setSimages(String simages) {
		Simages = simages;
	}
	
	
	
}
