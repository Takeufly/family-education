package com.fzu.userBean;

public class Teacher {


	private String Tno;
	private String Tname;
	private String Tsex;
	private String Tcourse;
	private String Timages;
	
	public String getTno() {
		return Tno;
	}
	public void setTno(String tno) {
		Tno = tno;
	}
	public String getTname() {
		return Tname;
	}
	public void setTname(String tname) {
		Tname = tname;
	}
	public String getTsex() {
		return Tsex;
	}
	public void setTsex(String tsex) {
		Tsex = tsex;
	}
	public String getTcourse() {
		return Tcourse;
	}
	public void setTcourse(String tcourse) {
		Tcourse = tcourse;
	}
	public String getTimages() {
		return Timages;
	}
	public void setTimages(String timages) {
		Timages = timages;
	}

}
