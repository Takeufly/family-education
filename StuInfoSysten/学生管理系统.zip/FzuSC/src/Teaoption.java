import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fzu.userBean.CourseBean;
import com.fzu.userBean.MyCourseBean;
import com.fzu.userBean.Student;
import com.fzu.userBean.Teacher;
import com.fzu.utils.CourseSqlUtils;
import com.fzu.utils.StuSqlUtils;
import com.fzu.utils.TeacherSqlUtils;


public class Teaoption extends HttpServlet {


	private String option;
	private HttpSession Session;
	private String userID;
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		Session = request.getSession();
		option = request.getParameter("option");
		userID = (String) Session.getAttribute("userID");
		
		Session.setAttribute("option",option);
		
		if(option.equals("welcome")){
			RequestDispatcher rd = request.getRequestDispatcher("../../teacher/index.jsp");
			rd.forward(request, response);
		}else if(option.equals("info")){
			List<Teacher> teas = TeacherSqlUtils.QueryTeacher(userID);
			Session.setAttribute("userINFO",teas);
			RequestDispatcher rd = request.getRequestDispatcher("../../teacher/index.jsp");
			rd.forward(request, response);
		}else if(option.equals("mySubject")){
			List<MyCourseBean> mycourse = CourseSqlUtils.getMyCourse(userID);
			Session.setAttribute("userCourse",mycourse);
			RequestDispatcher rd = request.getRequestDispatcher("../../teacher/index.jsp");
			rd.forward(request, response);
		}else if(option.equals("repswd")){
			RequestDispatcher rd = request.getRequestDispatcher("../../teacher/index.jsp");
			rd.forward(request, response);
		}else if(option.equals("logout")){
			Session.setAttribute("userID",null);
			Session.setAttribute("status","logout");
			response.sendRedirect("../../login.jsp");
		}
		
		
	}

	
}
